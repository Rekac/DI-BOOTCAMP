#predict output of each condition
print(5<3)
print(3==3)
print(3=='3') #error cause "3" is not int so needed to change to print(3==int('3'))
print(int("3")>3)
print("Hello"=="hello")