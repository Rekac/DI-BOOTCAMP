#Tall enoug to Ride the Roaller Coaster
Height=int(input("Enteryour Height in cm: "))
if Height>=145 :
    print("you can ride the Roaller Coaster")
else:
    print("Sorry, you can't play the Roaller Coaster")