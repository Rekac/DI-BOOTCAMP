#Even or Odd
a=int(input("Enter a number: "))
if a%2==0:
    print("The number {} is even".format(a))
else:
    print("The number{} is odd".format(a))