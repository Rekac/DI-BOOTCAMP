#comparing names
my_name='Renata'
user_name=input("Enter your name: ")
if my_name ==user_name:
    print("what a coincidence,we have the same name")
else:
    print("Nice to meet you "+user_name)