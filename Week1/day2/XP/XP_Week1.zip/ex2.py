#print calculation of (99^3)*8
calculation= (99**3)*8
print(calculation)
# other form is define the inputs 
#import math
#a=int(input("enter a number: "))
#b=int(input("enter a number: "))
#c=int(input("enter a number: "))
#r=(pow(a,b)*c)
#print(int(r))
