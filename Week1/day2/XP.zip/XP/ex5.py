#your information
name='Renta'
age= '25'
shoe_size='44'
info =f"Me name is " +name+ ", I am " +age+ " years old" " and my shoe size  is "+shoe_size+""
print(info)