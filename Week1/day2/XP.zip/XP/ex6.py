# Aand B
a=5
b=3
if a>b:
    print("Hello World")
else:
    print(" ")
    #more flexible wy
#a= input("enter  numer: ")
#b= input("enter  numer: ")
#if a>b:
 #   print("Hello World")
#else:
#    print(" ")