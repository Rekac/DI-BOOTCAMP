#Your Comp brand
computer_brand="lenovo" 
print('I have '+computer_brand+ ' computer')